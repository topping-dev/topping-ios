#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@class LuaTranslator;

@protocol LuaInterface
@required
-(NSString *)GetId;
@end
