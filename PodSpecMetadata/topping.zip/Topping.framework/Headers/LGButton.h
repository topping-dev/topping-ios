#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "LGTextView.h"

@interface LGButton : LGTextView 
{

}

+(LGButton*)Create:(LuaContext *)context;

@end
