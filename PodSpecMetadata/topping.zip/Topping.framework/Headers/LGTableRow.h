#import <Foundation/Foundation.h>
#import "LGLinearLayout.h"

@interface LGTableRow : LGLinearLayout

+(LGTableRow*)Create:(LuaContext *)context;

@end
