#import <Foundation/Foundation.h>
#import "LGLinearLayout.h"

@interface LGTableLayout : LGLinearLayout

+(LGTableLayout*)Create:(LuaContext *)context;

@end
