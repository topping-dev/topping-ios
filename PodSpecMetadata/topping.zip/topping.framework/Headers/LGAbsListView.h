#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>
#import "LGView.h"

@interface LGAbsListView : LGView 
{
/*
 
 android:cacheColorHint
 android:choiceMode
 android:drawSelectorOnTop
 android:fastScrollEnabled
 android:listSelector
 android:scrollingCache
 android:smoothScrollbar
 android:stackFromBottom
 android:textFilterEnabled
 android:transcriptMode
 
 */
}

@end
