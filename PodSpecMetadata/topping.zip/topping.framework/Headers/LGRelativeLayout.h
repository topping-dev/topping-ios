#import <Foundation/Foundation.h>
#import "LGViewGroup.h"

@interface LGRelativeLayout : LGViewGroup

+(LGRelativeLayout*)Create:(LuaContext *)context;

@end
