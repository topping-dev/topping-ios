#import "lua.h"
#import "lobject.h"

LUA_API const char *GetStr(TValue *val);
LUA_API void *RawUValue(StkId val);
