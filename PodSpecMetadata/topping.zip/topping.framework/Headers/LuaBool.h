#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface LuaBool : NSNumber
{
}

@end
