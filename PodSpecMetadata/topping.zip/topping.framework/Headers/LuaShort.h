#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface LuaShort : NSNumber
{

}

@end
