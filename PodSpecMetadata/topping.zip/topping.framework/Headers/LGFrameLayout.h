#import <Foundation/Foundation.h>
#import "LGViewGroup.h"

@interface LGFrameLayout : LGViewGroup

+(LGFrameLayout*)Create:(LuaContext *)context;

@end
