#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface LuaLong : NSNumber
{

}

@end
