#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface LuaDouble : NSNumber
{

}

@end
