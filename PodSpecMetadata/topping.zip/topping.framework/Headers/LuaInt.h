#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>


@interface LuaInt : NSNumber
{

}

@end
