# ToppingEngine

[![CI Status](https://img.shields.io/travis/Deadknight/Topping.svg?style=flat)](https://travis-ci.org/Deadknight/Topping)
[![Version](https://img.shields.io/cocoapods/v/Topping.svg?style=flat)](https://cocoapods.org/pods/Topping)
[![License](https://img.shields.io/cocoapods/l/Topping.svg?style=flat)](https://cocoapods.org/pods/Topping)
[![Platform](https://img.shields.io/cocoapods/p/Topping.svg?style=flat)](https://cocoapods.org/pods/Topping)

## Installation

Topping Engine is available through [CocoaPods](https://cocoapods.org). To install
ait, simply add the following line to your Podfile:

```ruby
pod 'Topping'
```

## Author

Topping Dev, topping.dev@gmail.com

## License

ToppingEngine is available under the CC BY-ND 4.0 license. See the LICENSE file for more info.
